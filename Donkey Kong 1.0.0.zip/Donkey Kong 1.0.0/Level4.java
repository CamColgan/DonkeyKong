import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level4 extends LevelState
{

    /**
     * Constructor for objects of class Level4.
     * 
     */
    public Level4()
    {
        Entity.level = 5;
    }
    
}
