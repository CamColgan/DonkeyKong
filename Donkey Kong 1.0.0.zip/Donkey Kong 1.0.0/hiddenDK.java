import greenfoot.*;
//hidden dk is invisible and only spawns barrels
public class hiddenDK extends Entity
{
    long lastTime;
    public void act() 
    {
        //makes barrels
        if(System.currentTimeMillis() - lastTime > 2500)
        {
            lastTime = System.currentTimeMillis();
            getWorld().addObject(new Barrel(), getX(), getY());
        }
    }    
}
