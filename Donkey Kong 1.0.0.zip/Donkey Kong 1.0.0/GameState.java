import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameState here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameState extends World
{
    public static int scale = 2;
    /**
     * Constructor for objects of class GameState.
     * 
     */
    public GameState()
    {    
        super(256, 256, scale);
    }
    public static int getScale() {
        return scale;
    }
}
