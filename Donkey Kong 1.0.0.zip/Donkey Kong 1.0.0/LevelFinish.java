import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
//this class is just a normal level but sets the background to a gif
public class LevelFinish extends LevelState
{
    GifImage background = new GifImage ("fireworks_0.gif");    
    /**
     * Constructor for objects of class LevelFinish.
     * 
     */
    public LevelFinish()
    {
        Entity.level = 6;
    }
    public void act(){
        //sets the background and scales it
        setBackground(background.getCurrentImage());
        GreenfootImage image = getBackground();
        image.scale((int)(image.getHeight() * 0.7 * scale), (int)(image.getHeight() * 0.7 * scale));
        setBackground(image); 
    }
}
