import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

// All level classes just hold the image that is used to determine entity placement
//and set level
public class Level0 extends LevelState
{
    
    public Level0()
    {
        //this makes sure mario starts with 3 lives
        Entity.Lives = 3;
        Entity.level = 1;
    }
}
