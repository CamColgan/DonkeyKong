import greenfoot.*;

public class Princess extends Entity

{
    /**
     * Act - do whatever the Princess wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    long lastTime = 0;
    public void act() 
    {
        if(System.currentTimeMillis() - lastTime > 1000)
        {
            //makes her dance
            lastTime = System.currentTimeMillis();
            getImage().mirrorHorizontally();
        }
    }    
}
