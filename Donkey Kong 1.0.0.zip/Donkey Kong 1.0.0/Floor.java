import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

//floor is just a sensor for other classes
public class Floor extends Entity
{
    public void Floor() {
        
        
    }
    public void act() {
        // Add your action code here.
    }
}
