import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

//ladder colider is a sensor for barrels to see if they can go down
public class LadderColider extends Entity
{
    /**
     * Act - do whatever the LadderColider wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
