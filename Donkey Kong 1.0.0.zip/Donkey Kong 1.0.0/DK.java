import greenfoot.*;
//this dk does visuals sound and hit detection. hidden dk spawns barrels
public class DK extends Entity
{
    long lastTime;
    GreenfootSound music = new GreenfootSound("sounds_music.mp3");
    GreenfootSound boss_music = new GreenfootSound("sounds_boss.mp3");
    public void act() 
    {  
        //music playing based off of level
        if((Entity.level < 5) && (Entity.level >= 0)) {
          music.playLoop();
          boss_music.stop();
        } else if (Entity.level >= 5) {
          boss_music.playLoop();
          music.stop();
        }
        if(isTouching(Mario.class))
        {
            //when you touch dk it sends you to appropriate level
            if(Entity.level == 1){
                Entity.level = 1;
                Greenfoot.setWorld(new Level1());
                music.stop();
            }
            else if(Entity.level == 2){
                Entity.level = 2;
                Greenfoot.setWorld(new Level2());
                music.stop();
            }
            else if(Entity.level == 3){
                Entity.level = 3;
                Greenfoot.setWorld(new Level3());
                music.stop();
            }
            else if(Entity.level == 4){
                Entity.level = 4;
                Greenfoot.setWorld(new Level4());
                music.stop();
            }
            else if(Entity.level == 5){
                Greenfoot.setWorld(new LevelFinish());
                music.stop();
                boss_music.stop();
            }
            else if(Entity.level == 6){
                Greenfoot.setWorld(new LevelFinish());
                music.stop();
            }
        }
        //makes dk dance
        if(System.currentTimeMillis() - lastTime > 200)
        {
            lastTime = System.currentTimeMillis();
            getImage().mirrorHorizontally();
        }
    }    
}
