import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

//just displays a picture
public class MarioLives extends Entity
{
    /**
     * Act - do whatever the MarioLives wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        //if mario runs out of lives it dissapears
        if(Entity.Lives < 1){
            getWorld().removeObject(this);
        }
    }
}
