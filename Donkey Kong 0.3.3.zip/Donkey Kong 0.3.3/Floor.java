import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Floor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Floor extends Entity
{
    public void Floor() {
        
        
    }
    public void act() {
        // Add your action code here.
    }
}
