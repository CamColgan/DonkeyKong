import greenfoot.*;
public class Mario extends Entity
{
    float speed;
    String Marioimage = "mario-left.png";
    char lastDirec = 'l';
    long lastTime;
    int Lives = 3;
    GreenfootSound music = new GreenfootSound("sounds_music.mp3");
    GreenfootSound game_over_sound = new GreenfootSound("sounds_game-over.mp3");    
    GreenfootSound hurt_sound = new GreenfootSound("sounds_barrels.mp3");  
    public void act() 
    {
        speed += 0.3;
        setLocation( getX(), getY() + (int)(speed));
        getWorld().showText("Lives : "+ Lives +"",1450, 50);
        music.playLoop();
    
        if(isTouching(Barrel.class))
        {
            removeTouching(Barrel.class);
            Lives = Lives - 1;
            hurt_sound.play();
        }
        if(Lives == 0)
        {
            game_over_sound.play();
            music.stop();
            getWorld().showText("GAME OVER", 750, 600);
            Greenfoot.stop();
        } 
        if(Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a"))
        {
            move(-2);
            lastDirec = 'l';
            if(isTouching(Floor.class)){
                if(((System.currentTimeMillis() - lastTime) > 200) && (Marioimage == "mario-left.png" || Marioimage == "mario-jump.png"))
                {
                    Marioimage = "mario-left-w1.png";
                    
                    lastTime = System.currentTimeMillis();
                    
                }
                if(((System.currentTimeMillis() - lastTime) > 200) && Marioimage == "mario-left-w1.png")
                {
                    Marioimage = "mario-left-w2.png";
                    
                    lastTime = System.currentTimeMillis();
                    
                }
                if(((System.currentTimeMillis() - lastTime) > 200) && Marioimage == "mario-left-w2.png")
                {
                    Marioimage = "mario-left.png";
                    
                    lastTime = System.currentTimeMillis();
                    
                }
            }
        } 
        else if(Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d")){   
               move(2);
               lastDirec = 'r';
               if(isTouching(Floor.class)){
                if(((System.currentTimeMillis() - lastTime) > 200) && (Marioimage == "mario-left.png" || Marioimage == "mario-jump.png"))
                   {
                    Marioimage = "mario-left-w1.png";
                    
                    
                    lastTime = System.currentTimeMillis();
                    
                }
                if(((System.currentTimeMillis() - lastTime) > 200) && Marioimage == "mario-left-w1.png")
                {
                    Marioimage = "mario-left-w2.png";
                    
                    
                    lastTime = System.currentTimeMillis();
                    
                }
                if(((System.currentTimeMillis() - lastTime) > 200) && Marioimage == "mario-left-w2.png") 
                {
                    Marioimage = "mario-left.png";
                    lastTime = System.currentTimeMillis();
    
                }
            }
        }
        else if((Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s")) && (!isTouching(Ladder.class)))
        {
            speed = 10;
            }
        if(isTouching(Ladder.class)){
            speed = 0;
            if(Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("w"))
            {
                speed = - 2;
                Marioimage = "mario-jump.png";
                setImage(Marioimage);
                scaling();
            }
            if(Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s"))
            {
                speed = 2;
                Marioimage = "mario-jump.png";
                setImage(Marioimage);
                scaling();   
            }
            while(isTouching(Floor.class))
                {
                    speed = 0;
                    setLocation(getX(), getY() - 1);
                }   
        }
            if (speed > 0){
            while(isTouching(Floor.class))
            {
                speed = 0;
                setLocation(getX(), getY() - 1);
                if(Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("w"))
                {
                    speed = - 7;
                    Marioimage = "mario-jump.png";
                    setImage(Marioimage);
                    scaling();
                }
            }
        }
        if(speed <= 0)
        {
            while(isTouching(Floor.class))
            {
                speed = 0;
                setLocation(getX(), getY() + 1);
            }
        }   
        if (lastDirec == 'r'){
            setImage(Marioimage);
            getImage().mirrorHorizontally();
            scaling();
        }
        else if (lastDirec == 'l'){
            setImage(Marioimage);
            scaling();
        }
        //scaling bc mario shrank :(
    }
    public void scaling(){
        GreenfootImage image = getImage();
        image.scale(image.getHeight() * GameState.getScale(), image.getHeight() * GameState.getScale());
        setImage(image);
    }
}