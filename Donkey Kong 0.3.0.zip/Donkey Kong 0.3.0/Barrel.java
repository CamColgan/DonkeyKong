import greenfoot.*;

/**
 * Write a description of class Barrel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Barrel extends Entity
{
    float speedY;
    float speedX = 0;
    public void act() 
    {
        setLocation( getX() + (int)speedX, getY() + (int)speedY);
        speedY += 0.1;
        if(isAtEdge()) {
            getWorld().removeObject(this);
        } else {
            turn(7 * (int)speedX);
            if(speedY > 0) {
                if(isTouching(Floor.class))
                {
                    speedY = (float)-0.5;
                }
            }
            if(speedY <= 0) {
                if(isTouching(Floor.class))
                {
                    speedY = (float)0.1;
                    if(isTouching(Floor2.class)){
                        speedX = -1;   
                    } else {
                        speedX = 1;     
                    }
                }
            }
        }
    }
}
 