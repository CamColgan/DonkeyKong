import greenfoot.*;
public class DK extends Entity
{
    long lastTime;
    GreenfootSound music = new GreenfootSound("sounds_music.mp3");
    public void act() 
    {  
        music.playLoop();
        if (Entity.Lives == 0){
            music.stop();
        }
        if(isTouching(Mario.class))
        {
            if(Entity.level == 1){
                Entity.level = 1;
                Greenfoot.setWorld(new Level1());
                music.stop();
            }
            else if(Entity.level == 2){
                Entity.level = 2;
                Greenfoot.setWorld(new Level2());
                music.stop();
            }
            else if(Entity.level == 3){
                Entity.level = 3;
                Greenfoot.setWorld(new Level3());
                music.stop();
            }
            else if(Entity.level == 4){
                Entity.level = 4;
                Greenfoot.setWorld(new Level4());
                music.stop();
            }
            else if(Entity.level == 5){
                Greenfoot.setWorld(new LevelFinish());
                music.stop();
            }
        }
        if(System.currentTimeMillis() - lastTime > 200)
        {
            lastTime = System.currentTimeMillis();
            getImage().mirrorHorizontally();
        }
    }    
}
