import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Entity here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Entity extends Actor
{
    public static int Lives = 3;
    public static int level = 1;
    public Entity() {
        GreenfootImage image = getImage();
        image.scale(image.getHeight() * GameState.getScale(), image.getHeight() * GameState.getScale());
        setImage(image); 
    }
    /**
     * Act - do whatever the Entity wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        
    }
}
