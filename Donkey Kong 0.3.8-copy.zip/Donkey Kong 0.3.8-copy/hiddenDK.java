import greenfoot.*;
public class hiddenDK extends Entity
{
    long lastTime;
    public void act() 
    {
        if(System.currentTimeMillis() - lastTime > 2500)
        {
            lastTime = System.currentTimeMillis();
            getWorld().addObject(new Barrel(), getX(), getY());
        }
    }    
}
