import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelFinish here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelFinish extends LevelState
{
    GifImage background = new GifImage ("fireworks_0.gif");    
    /**
     * Constructor for objects of class LevelFinish.
     * 
     */
    public LevelFinish()
    {
        Entity.level = 6;
        setBackground(background.getCurrentImage());
    }
    public void act(){
        setBackground(background.getCurrentImage());
        GreenfootImage image = getBackground();
        image.scale((int)(image.getHeight() * 0.7 * scale), (int)(image.getHeight() * 0.7 * scale));
        setBackground(image); 
    }
}
