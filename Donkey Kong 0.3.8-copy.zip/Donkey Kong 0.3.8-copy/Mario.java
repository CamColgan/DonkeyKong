import greenfoot.*;
public class Mario extends Entity
{
    float speed;
    String Marioimage = "mario-left.png";
    char lastDirec = 'l';
    long lastTime = System.currentTimeMillis();
    GreenfootSound game_over_sound = new GreenfootSound("sounds_game-over.mp3");    
    GreenfootSound hurt_sound = new GreenfootSound("sounds_barrels.mp3");  
    public void act() 
    {
        speed += 0.3;
        setLocation( getX(), getY() + (int)(speed));
        getWorld().showText("Lives : "+ Entity.Lives +"",1450, 50);
        if(isTouching(Barrel.class))
        {
            removeTouching(Barrel.class);
            Lives = Lives - 1;
            hurt_sound.play();
        }
        if(Entity.Lives == 0)
        {
            game_over_sound.play();
            Greenfoot.stop();
        }
        if((!Greenfoot.isKeyDown("left")) && (!Greenfoot.isKeyDown("a")) && (!Greenfoot.isKeyDown("right")) && (!Greenfoot.isKeyDown("d")) && (isTouching(Floor.class)) && (!isTouching(Ladder.class)))
            {
                    Marioimage = "mario-left.png";
            }
        if(isTouching(Ladder.class)){
                    speed = 0;
            if(isTouching(Floor.class))
                    {
                if((!Greenfoot.isKeyDown("up")) && (!Greenfoot.isKeyDown("space")) && (!Greenfoot.isKeyDown("w")) && (!Greenfoot.isKeyDown("down")) && (!Greenfoot.isKeyDown("s")))
                    { 
                        setLocation(getX(), getY() - 1);
                    } 
                    }
            if(Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("w"))
                {
                    speed = - 2;
                    Marioimage = "mario-climb.png";
                    if(System.currentTimeMillis() - lastTime > 300 && lastDirec == 'r')
                    {  
                        lastTime = System.currentTimeMillis();
                        lastDirec = 'l';
                    }
                    if(System.currentTimeMillis() - lastTime > 300 && lastDirec == 'l')
                    {  
                        lastTime = System.currentTimeMillis();
                        lastDirec = 'r';
                    }
                }
                else if(Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s"))
                {
                    speed = 2;
                    Marioimage = "mario-climb.png";
                    if(System.currentTimeMillis() - lastTime > 200 && lastDirec == 'r')
                    {  
                        lastTime = System.currentTimeMillis();
                        lastDirec = 'l';
                    }
                    if(System.currentTimeMillis() - lastTime > 200 && lastDirec == 'l')
                    {  
                        lastTime = System.currentTimeMillis();
                        lastDirec = 'r';
                    }
                }
        }
        if(Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a"))
            {
                move(-1);
                lastDirec = 'l';
                if(isTouching(Floor.class)){
                    if(((System.currentTimeMillis() - lastTime) > 100) && (Marioimage == "mario-left.png" || Marioimage == "mario-jump.png" || Marioimage == "mario-climb.png"))
                    {
                        Marioimage = "mario-left-w1.png";
                        lastTime = System.currentTimeMillis();
                    }
                    if(((System.currentTimeMillis() - lastTime) >100) && Marioimage == "mario-left-w1.png")
                    {
                        Marioimage = "mario-left-w2.png";
                        lastTime = System.currentTimeMillis();
                    }
                    if(((System.currentTimeMillis() - lastTime) > 100) && Marioimage == "mario-left-w2.png")
                    {
                        Marioimage = "mario-left.png";
                        lastTime = System.currentTimeMillis();
                    }
                }
            } 
            else if(Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d")){   
                move(1);
                lastDirec = 'r';
                if(isTouching(Floor.class)){
                    if(((System.currentTimeMillis() - lastTime) > 100) && (Marioimage == "mario-left.png" || Marioimage == "mario-jump.png" || Marioimage == "mario-climb.png"))
                       {
                        Marioimage = "mario-left-w1.png";
                        lastTime = System.currentTimeMillis();
                    }
                    if(((System.currentTimeMillis() - lastTime) > 100) && Marioimage == "mario-left-w1.png")
                    {
                        Marioimage = "mario-left-w2.png";
                        lastTime = System.currentTimeMillis();
                    }
                    if(((System.currentTimeMillis() - lastTime) > 100) && Marioimage == "mario-left-w2.png") 
                    {
                        Marioimage = "mario-left.png";
                        lastTime = System.currentTimeMillis();
                    }
                }
            }
            else if((Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s")) && (!isTouching(Ladder.class)))
            {
                speed = 10;
                }
        if(!isTouching(Ladder.class)){
                if (speed > 0){
                while(isTouching(Floor.class))
                {
                    speed = 0;
                    setLocation(getX(), getY() - 1);
                    if(Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("w"))
                    {
                        speed = - 6;
                        Marioimage = "mario-jump.png";
                        setImage(Marioimage);
                        scaling();
                    }
                }
            }
            if(speed <= 0)
            {
                while(isTouching(Floor.class))
                {
                    speed = 0;
                    setLocation(getX(), getY() + 1);
                }
            }
        }
        if (Entity.Lives == 0){
            Marioimage = "empty.png";
        }
        if (lastDirec == 'r'){
                    setImage(Marioimage);
                    getImage().mirrorHorizontally();
                    scaling();
                }
            else if (lastDirec == 'l'){
                    setImage(Marioimage);
                    scaling();
                }
    }
    public void scaling(){
        GreenfootImage image = getImage();
        image.scale(image.getHeight() * GameState.getScale(), image.getHeight() * GameState.getScale());
        setImage(image);
    }
}