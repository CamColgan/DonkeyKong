import greenfoot.*;

/**
 * Write a description of class Princess here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Princess extends Entity

{
    /**
     * Act - do whatever the Princess wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    GreenfootSound win_music = new GreenfootSound("sounds_jump-up.mp3");
    GreenfootSound boss_music = new GreenfootSound("sounds_boss.mp3");
    long lastTime = 0;
    public void act() 
    {
        boss_music.stop();
        win_music.playLoop();
        if(System.currentTimeMillis() - lastTime > 1000)
        {
            lastTime = System.currentTimeMillis();
            getImage().mirrorHorizontally();
        }
    }    
}
