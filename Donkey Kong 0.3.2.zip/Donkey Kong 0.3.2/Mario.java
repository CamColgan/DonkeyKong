import greenfoot.*;
import greenfoot.GreenfootSound;
public class Mario extends Entity
{
    int speed;
    String Marioimage = "";
    char lastDirec = 'r';
    long lastTime;
    int Lives = 3;
    
    GreenfootSound sound = new GreenfootSound("music.mp3");
    
    public void act()
    
    {
        sound.playLoop();
        speed = speed + 1;
        setLocation( getX(), getY() + speed);
        getWorld().showText("Lives : "+ Lives +"",1450, 50);
        if((lastDirec == 'r') && (isTouching(Floor.class)))
        {
        Marioimage = "mario-left.png";
        setImage(Marioimage);
        getImage().mirrorHorizontally();
    }
    else if ((lastDirec == 'l') && (isTouching(Floor.class)))
    {
        Marioimage = "mario-left.png";
        setImage(Marioimage);
        getImage().mirrorHorizontally();
    }
    else if((lastDirec == 'r') && (!isTouching(Floor.class)))
        {
        Marioimage = "mario-left.png";
        setImage(Marioimage);
        getImage().mirrorHorizontally();
    }
    else if ((lastDirec == 'l') && (!isTouching(Floor.class)))
    {
        Marioimage = "mario-jump.png";
        setImage(Marioimage);
    }
        if(isTouching(Barrel.class))
        {
            removeTouching(Barrel.class);
            Lives = Lives - 1;
        }
        if(Lives == 0)
        {
            getWorld().showText("GAME OVER", 750, 600);
            sound.stop();
        }
        if(speed > 0)
        {
            while(isTouching(Floor.class))
            {
                speed = 0;
                setLocation(getX(), getY() - 1);
                if(Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("w"))
                {
                    if((lastDirec == 'r') && (!isTouching(Floor.class)))
                        {
                        Marioimage = "mario-left.png";
                        setImage(Marioimage);
                        getImage().mirrorHorizontally();
                    }
                    else if ((lastDirec == 'l') && (!isTouching(Floor.class)))
                    {
                        Marioimage = "mario-jump.png";
                        setImage(Marioimage);
                    }
                    speed = - 12;
                }
            }
        }
        if(speed <= 0)
        {
            while(isTouching(Floor.class))
            {
                speed = 0;
                setLocation(getX(), getY() + 1);
            }
        }    
        if(Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a"))
        {
            move(-2);
            lastDirec = 'l';
            if((System.currentTimeMillis() - lastTime) > 1000)
            {
                Marioimage = "mario-left-w1.png";
                setImage(Marioimage);
                lastTime = System.currentTimeMillis();
            }
            if((System.currentTimeMillis() - lastTime) > 1000)
            {
                Marioimage = "mario-left-w2.png";
                setImage(Marioimage);
                lastTime = System.currentTimeMillis();
            }
            if((System.currentTimeMillis() - lastTime) > 1000)  
            {
                Marioimage = "mario-left.png";
                setImage(Marioimage);
                lastTime = System.currentTimeMillis();
            }
            while(isTouching(Floor.class))
            {
               move(1);
            } 
        } else {
            if(Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d"))
            {   
               move(2);
               lastDirec = 'r';
               if((System.currentTimeMillis() - lastTime) > 1000)
               {
                Marioimage = "mario-left-w1.png";
                setImage(Marioimage);
                getImage().mirrorHorizontally();
                lastTime = System.currentTimeMillis();
            }
            if((System.currentTimeMillis() - lastTime) > 1000)
            {
                Marioimage = "mario-left-w2.png";
                setImage(Marioimage);
                getImage().mirrorHorizontally();
                lastTime = System.currentTimeMillis();
            }
            if((System.currentTimeMillis() - lastTime) > 1000) 
            {
                Marioimage = "mario-left.png";
                setImage(Marioimage);
                getImage().mirrorHorizontally();
                lastTime = System.currentTimeMillis();
            }
                while(isTouching(Floor.class))
                {
                  move(-1);
               }
        }
        if(Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s"))
        {
            speed = 10;
            }
        } 
        //scaling bc mario shrank :(
        GreenfootImage image = getImage();
        image.scale(image.getHeight() * GameState.getScale(), image.getHeight() * GameState.getScale());
        setImage(image);
    }
}