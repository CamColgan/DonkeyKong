import greenfoot.*;

/**
 * Write a description of class BackGround1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date) 
 */

public class LevelState extends GameState
{
    /**
     * Constructor for objects of class BackGround1.
     * 
     */
    public LevelState()
    {    

        // Loading Level Image
        GreenfootImage image = getBackground();
        image.scale(image.getHeight() * 8 * scale, image.getHeight() * 8 * scale);
        setBackground(image); 
        
        // Level Builder
        for (int i = 0; i < 1024; i++) {
            if (getColorAt((i / 32) * 8,(i % 32) * 8).equals(Color.RED)){
                addObject(new Floor(), (i / 32) * 8 + 4, (i % 32) * 8 + 4);
            }
            if (getColorAt((i / 32) * 8,(i % 32) * 8).equals(Color.GREEN)){
                addObject(new Floor2(), (i / 32) * 8 + 4, (i % 32) * 8 + 4);
            }
            if (getColorAt((i / 32) * 8,(i % 32) * 8).equals(Color.YELLOW)){
                addObject(new DK(), (i / 32) * 8 + 4, (i % 32) * 8);
            }
            if (getColorAt((i / 32) * 8,(i % 32) * 8).equals(Color.BLUE)){
                addObject(new Mario(), (i / 32) * 8 + 4, (i % 32) * 8);
            }
            if (getColorAt((i / 32) * 8,(i % 32) * 8).equals(Color.CYAN)){
                addObject(new Ladder(), (i / 32) * 8 + 4, (i % 32) * 8 + 4);
            }
        }
        // Normal Object Loading

        // Set Default Background
        setBackground("Background.png");
        
    }
}
