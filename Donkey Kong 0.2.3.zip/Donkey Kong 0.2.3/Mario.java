import greenfoot.*;
public class Mario extends Entity
{
    int speed;
    String Marioimage = "mario-left.png";
    long lastTime;
    int Lives = 3;
    public void act() 
    {
        speed = speed + 1;
        setLocation( getX(), getY() + speed);
        getWorld().showText("Lives : "+ Lives +"",1450, 50);
        if(isTouching(Barrel.class))
        {
            removeTouching(Barrel.class);
            Lives = Lives - 1;
        }
        if(Lives == 0)
        {
            getWorld().showText("GAME OVER", 750, 600);
            Greenfoot.stop();
        }
        if(speed > 0)
        {
            while(isTouching(Floor.class))
            {
                speed = 0;
                setLocation(getX(), getY() - 1);
                if(Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("w"))
                {
                    Marioimage = "mario-jump.png";
                    setImage(Marioimage);
                    speed = - 27;
                }
            }
        }
        if(speed <= 0)
        {
            while(isTouching(Floor.class))
            {
                speed = 0;
                setLocation(getX(), getY() + 1);
            }
        }    
        if(Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a"))
        {
            move(-5);
            Marioimage = "mario-left.png";
                setImage(Marioimage);
            if(((System.currentTimeMillis() - lastTime) > 1000) && (Marioimage.equals("mario-left.png")))
            {
                Marioimage = "mario-left-w1.png";
                setImage(Marioimage);
                lastTime = System.currentTimeMillis();
            }
            if(((System.currentTimeMillis() - lastTime) > 1000) && (Marioimage.equals("mario-left-w1.png")))
            {
                Marioimage = "mario-left-w2.png";
                setImage(Marioimage);
                lastTime = System.currentTimeMillis();
            }
            if(((System.currentTimeMillis() - lastTime) > 1000) && (Marioimage.equals("mario-left-w2.png")))
            {
                Marioimage = "mario-left.png";
                setImage(Marioimage);
                lastTime = System.currentTimeMillis();
            }
            while(isTouching(Floor.class))
            {
               move(1);
            } 
        } else {
            if(Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d"))
            {   
               move(5);
               Marioimage = "mario-left.png";
               setImage(Marioimage);
               getImage().mirrorHorizontally();
               if(((System.currentTimeMillis() - lastTime) > 1000) && (Marioimage.equals("mario-left.png")))
            {
                Marioimage = "mario-left-w1.png";
                setImage(Marioimage);
                getImage().mirrorHorizontally();
                lastTime = System.currentTimeMillis();
            }
            if(((System.currentTimeMillis() - lastTime) > 1000) && (Marioimage.equals("mario-left-w1.png")))
            {
                Marioimage = "mario-left-w2.png";
                setImage(Marioimage);
                getImage().mirrorHorizontally();
                lastTime = System.currentTimeMillis();
            }
            if(((System.currentTimeMillis() - lastTime) > 1000) && (Marioimage.equals("mario-left-w2.png")))
            {
                Marioimage = "mario-left.png";
                setImage(Marioimage);
                getImage().mirrorHorizontally();
                lastTime = System.currentTimeMillis();
            }
                while(isTouching(Floor.class))
                {
                  move(-1);
               }
        }
        if(Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s"))
        {
            speed = 50;
            }
        } 
    }
}