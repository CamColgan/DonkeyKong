import greenfoot.*;

/**
 * Write a description of class Barrel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Barrel extends Entity
{
    float speedY;
    float speedX = 0;
    float animation = 1;
    int animationFall = 1;
    boolean canFall = true;
    boolean fall = false;
    int fallCount = 20;
    int ladderCount = 30;
    GreenfootSound sound = new GreenfootSound("sounds_hit.wav");
    public void act() 
    {
        setLocation(getX() + (int)speedX, getY() + (int)speedY);
        speedY += 0.2;
        if(isAtEdge()) {
            getWorld().removeObject(this);
            sound.play();
        } else {
            if(speedX > 0) {
                animation += 0.7;
            } else if (speedX < 0) {
                animation -= 0.7;
            }
            if(animation < 1) {
                animation = 24;
            }
            if(animation > 24) {
                animation = 1;
            }
            if (fall == true){
                animationFall++;
                setImage("barrelFall" + ((animationFall % 4) + 1) + ".png");
            } else {
                setImage("barrel" + ((int)(animation)) + ".png");
            }
            GreenfootImage image = getImage();
            image.scale(image.getHeight() * GameState.getScale(), image.getHeight() * GameState.getScale());
            setImage(image);
            if(isTouching(LadderColider.class)){
                if((canFall == true)){
                    canFall = false;
                    ladderCount = 0;
                    if(Greenfoot.getRandomNumber(100) > 50){
                       fall = true; 
                       fallCount = 20;
                       speedX = 0;
                       setLocation(((getX() / 8) * 8) + 4, getY());
                    }
                }
            }
            if ((canFall == false) && (ladderCount < 30)){
                ladderCount ++;
            } else if ((canFall == false) && (ladderCount >= 30)){
                canFall = true;
            }
            if(fall == true) {
                fallCount --;
                if(isTouching(Floor.class) && fallCount < 1){
                    fallCount = 20;
                    fall = false;
                }
            }
            if(isTouching(Floor.class) && (fall == false)) {
                if(isTouching(Floor2.class)){
                        speedX = -1;   
                    } else {
                        speedX = 1;     
                    }
                setLocation(getX(), getY() - 1);
                if(speedY > 1){
                    while(isTouching(Floor.class)){
                        setLocation(getX(), getY() - 1);
                    }
                }
                speedY = -speedY * (float)0.5;
                if(speedY > -2){
                    speedY = 0;
                }
            }
        }
    }
}
 