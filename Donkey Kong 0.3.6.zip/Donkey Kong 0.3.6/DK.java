import greenfoot.*;
public class DK extends Entity
{
    long lastTime;
    GreenfootSound music = new GreenfootSound("sounds_music.mp3");
    public void act() 
    {   music.playLoop();
        if(System.currentTimeMillis() - lastTime > 200)
        {
            lastTime = System.currentTimeMillis();
            getImage().mirrorHorizontally();
        }
    }    
}
