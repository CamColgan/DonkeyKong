import greenfoot.*;
public class DK extends Entity
{
    long lastTime;
    public void act() 
    {  
        if(System.currentTimeMillis() - lastTime > 200)
        {
            lastTime = System.currentTimeMillis();
            getImage().mirrorHorizontally();
        }
    }    
}
