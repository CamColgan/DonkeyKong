import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelFinish here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelFinish extends LevelState
{

    /**
     * Constructor for objects of class LevelFinish.
     * 
     */
    public LevelFinish()
    {
    }
}
