import greenfoot.*;
public class hiddenDK extends Entity
{
    long lastTime;
    GreenfootSound music = new GreenfootSound("sounds_music.mp3");
    public void act() 
    {
        music.playLoop();
        if(isTouching(Mario.class))
        {
            if(GameState.level == 0){
                GameState.level += 1;
                Greenfoot.setWorld(new Level1());
                music.stop();
            }
            else if(GameState.level == 1){
                GameState.level += 2;
                Greenfoot.setWorld(new Level2());
                music.stop();
            }
            else if(GameState.level == 2){
                GameState.level += 3;
                Greenfoot.setWorld(new Level3());
                music.stop();
            }
            else if(GameState.level == 3){
                GameState.level += 4;
                Greenfoot.setWorld(new Level4());
                music.stop();
            }
            else if(GameState.level == 4){
                Greenfoot.setWorld(new LevelFinish());
                music.stop();
            }
        }
        if(System.currentTimeMillis() - lastTime > 2500)
        {
            lastTime = System.currentTimeMillis();
            getWorld().addObject(new Barrel(), getX(), getY());
        }
    }    
}
